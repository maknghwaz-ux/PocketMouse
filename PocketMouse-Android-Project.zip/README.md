# Pocket Mouse (Android prototype)

This is a small Android app prototype with a movable floating touchpad, Left, Right/long-press, Scroll and close controls.

## Build an APK using only your Android phone
1. Create a GitHub account if you do not already have one.
2. In GitHub, create a new **public or private repository** named `PocketMouse`.
3. Upload the contents of this ZIP (not the ZIP file itself) to the repository, preserving the folder structure. You can use GitHub's website in your phone browser; uploading multiple files/folders is easiest with the GitHub app or a mobile code editor that supports Git.
4. Open the repository's **Actions** tab, choose **Build Pocket Mouse APK**, then tap **Run workflow**. The workflow also starts automatically after you push the files to `main` or `master`.
5. When it finishes, open the completed run, scroll to **Artifacts**, and download `PocketMouse-debug-apk`. Extract it and install `app-debug.apk`. If Android warns about unknown apps, allow installs for the browser/file manager you used.

## First launch
1. Open Pocket Mouse.
2. Tap **1. Enable Pocket Mouse accessibility**, find Pocket Mouse controls in Accessibility settings, and turn it on.
3. Return to the app and allow **display over other apps**.
4. Tap **3. Start floating touchpad**.
5. Drag the top bar to move the mini-window. Use the touchpad and buttons. Tap ✕ to close it.

## Important limitations
- Android does not let an ordinary app inject system-wide clicks without explicit Accessibility permission (or root). This prototype uses Android's AccessibilityService gesture API.
- The touchpad uses simulated touch gestures, not a true hardware mouse pointer/cursor. Some apps, system screens, games, secure screens, or Android versions may block or handle gestures differently.
- Right Click is implemented as a long press because Android apps generally do not expose a universal right-click action.
- Scroll is a vertical swipe gesture.
- This is a starter prototype, not a fully tested release. Test on your phone and report the Android version and what does/doesn't work so it can be refined.
