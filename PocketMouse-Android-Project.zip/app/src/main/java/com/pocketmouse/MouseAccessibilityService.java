package com.pocketmouse;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.view.Display;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public class MouseAccessibilityService extends AccessibilityService {
    public static MouseAccessibilityService instance;
    @Override public void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public void tap(float x, float y, long holdMs) {
        if (Build.VERSION.SDK_INT < 24) return;
        Path p = new Path(); p.moveTo(clampX(x), clampY(y));
        GestureDescription.StrokeDescription s = new GestureDescription.StrokeDescription(p, 0, Math.max(60, holdMs));
        dispatchGesture(new GestureDescription.Builder().addStroke(s).build(), null, null);
    }

    public void swipe(float x1, float y1, float x2, float y2, long duration) {
        if (Build.VERSION.SDK_INT < 24) return;
        Path p = new Path(); p.moveTo(clampX(x1), clampY(y1)); p.lineTo(clampX(x2), clampY(y2));
        dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(80, duration))).build(), null, null);
    }

    private float clampX(float x) { return Math.max(1, Math.min(getResources().getDisplayMetrics().widthPixels - 2, x)); }
    private float clampY(float y) { return Math.max(1, Math.min(getResources().getDisplayMetrics().heightPixels - 2, y)); }
}
