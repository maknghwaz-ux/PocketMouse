package com.pocketmouse;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setBackgroundColor(0xFFF5F7FA);

        TextView title = new TextView(this);
        title.setText("Pocket Mouse");
        title.setTextSize(28);
        title.setTextColor(0xFF101820);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("A tiny floating touchpad for controlling taps and swipes on your Android phone. First enable Accessibility, then allow display over other apps.");
        info.setTextSize(16);
        info.setTextColor(0xFF334155);
        info.setPadding(0, dp(12), 0, dp(18));
        root.addView(info);

        Button accessibility = new Button(this);
        accessibility.setText("1. Enable Pocket Mouse accessibility");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility);

        Button overlay = new Button(this);
        overlay.setText("2. Allow display over other apps");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else startOverlay();
        });
        root.addView(overlay);

        Button start = new Button(this);
        start.setText("3. Start floating touchpad");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            } else startOverlay();
        });
        root.addView(start);

        TextView note = new TextView(this);
        note.setText("How it works: drag on the pad to move the control point; Left Click taps; Right Click performs a long press; Scroll sends a vertical swipe. Android requires you to explicitly enable the accessibility service.");
        note.setTextSize(14);
        note.setTextColor(0xFF475569);
        note.setPadding(0, dp(20), 0, 0);
        root.addView(note);
        setContentView(root);
    }

    private void startOverlay() {
        startService(new Intent(this, FloatingMouseService.class));
        finish();
    }
}
