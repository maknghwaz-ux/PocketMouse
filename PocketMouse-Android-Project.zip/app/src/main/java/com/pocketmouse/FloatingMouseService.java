package com.pocketmouse;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingMouseService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;
    private float pointerX = 0, pointerY = 0;
    private boolean pointerReady = false;
    private float downX, downY, lastX, lastY;
    private int screenW, screenH;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        screenW = getResources().getDisplayMetrics().widthPixels;
        screenH = getResources().getDisplayMetrics().heightPixels;
        pointerX = screenW / 2f; pointerY = screenH / 2f; pointerReady = true;
        buildPanel();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextSize(11); b.setAllCaps(false);
        b.setPadding(dp(2), 0, dp(2), 0); b.setMinHeight(dp(38)); b.setMinimumHeight(dp(38));
        b.setOnClickListener(v -> action.run()); return b;
    }

    private void buildPanel() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL); outer.setPadding(dp(8), dp(6), dp(8), dp(7));
        outer.setBackground(bg(0xEE17212B, 16));
        TextView header = new TextView(this);
        header.setText("POCKET MOUSE     ⋮");
        header.setTextColor(Color.WHITE); header.setTextSize(12); header.setPadding(dp(4), dp(2), dp(4), dp(5));
        header.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ix, iy;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { sx=e.getRawX(); sy=e.getRawY(); ix=params.x; iy=params.y; return true; }
                if (e.getAction() == MotionEvent.ACTION_MOVE) { params.x=ix+(int)(e.getRawX()-sx); params.y=iy+(int)(e.getRawY()-sy); wm.updateViewLayout(panel,params); return true; }
                return true;
            }
        });
        outer.addView(header);

        View pad = new View(this);
        pad.setBackground(bg(0xFF293847, 12));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(220), dp(112));
        pp.bottomMargin = dp(5); outer.addView(pad, pp);
        pad.setOnTouchListener((v,e) -> {
            switch(e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX=e.getRawX(); downY=e.getRawY(); lastX=downX; lastY=downY; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx=e.getRawX()-lastX, dy=e.getRawY()-lastY;
                    // Touchpad relative movement: map pad movement to a practical screen-pointer movement.
                    pointerX += dx * 2.0f; pointerY += dy * 2.0f;
                    pointerX=Math.max(2,Math.min(screenW-2,pointerX)); pointerY=Math.max(2,Math.min(screenH-2,pointerY));
                    if (MouseAccessibilityService.instance != null) {
                        MouseAccessibilityService.instance.swipe(pointerX-dx*2, pointerY-dy*2, pointerX, pointerY, 100);
                    }
                    lastX=e.getRawX(); lastY=e.getRawY(); return true;
                case MotionEvent.ACTION_UP: return true;
            }
            return true;
        });

        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(button("← Left", () -> { if (MouseAccessibilityService.instance != null) MouseAccessibilityService.instance.tap(pointerX,pointerY,70); }), new LinearLayout.LayoutParams(0, dp(40), 1));
        row.addView(button("Right", () -> { if (MouseAccessibilityService.instance != null) MouseAccessibilityService.instance.tap(pointerX,pointerY,650); }), new LinearLayout.LayoutParams(0, dp(40), 1));
        row.addView(button("Scroll ▲▼", () -> { if (MouseAccessibilityService.instance != null) MouseAccessibilityService.instance.swipe(pointerX,pointerY+dp(55),pointerX,pointerY-dp(55),350); }), new LinearLayout.LayoutParams(0, dp(40), 1));
        row.addView(button("✕", this::stopSelf), new LinearLayout.LayoutParams(dp(40), dp(40)));
        outer.addView(row);

        panel = outer;
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        params = new WindowManager.LayoutParams(dp(250), WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END; params.x = dp(10); params.y = dp(100);
        wm.addView(panel, params);
    }

    @Override public void onDestroy() {
        if (wm != null && panel != null) try { wm.removeView(panel); } catch(Exception ignored) {}
        super.onDestroy();
    }
}
